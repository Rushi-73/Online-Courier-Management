﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OCMSystem.Models
{
    public partial class AdminTable
    {
        public int AdminId { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string MailId { get; set; }
        public string MobileNumber { get; set; }
    }
}
