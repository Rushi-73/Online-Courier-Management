﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OCMSystem.Models
{
    public partial class Detable
    {
        public Detable()
        {
            CourierTables = new HashSet<CourierTable>();
        }

        public int Deid { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string MailId { get; set; }
        public string MobileNumber { get; set; }
        public int? Salary { get; set; }

        public virtual ICollection<CourierTable> CourierTables { get; set; }
    }
}
