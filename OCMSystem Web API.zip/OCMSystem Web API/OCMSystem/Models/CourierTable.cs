﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OCMSystem.Models
{
    public partial class CourierTable
    {
        public int CourierId { get; set; }
        public string Consigner { get; set; }
        public string Consignee { get; set; }
        public string Consignment { get; set; }
        public string PackageType { get; set; }
        public double? PackageWeight { get; set; }
        public double? ServiceCost { get; set; }
        public string DeliveryStatus { get; set; }
        public int? UserId { get; set; }
        public int? Deid { get; set; }

        public virtual Detable De { get; set; }
        public virtual UserTable User { get; set; }
    }
}
