﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OCMSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OCMSystem.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AdminController : ControllerBase
    {
        [HttpPost("Create a New User")]
        public string CreateUser(int user_id, string first_name, string last_name, string mail_id, string mobile_number)
        {
            using (var context = new OCMSystemDBContext())
            {
                UserTable user = new UserTable();

                user.UserId = user_id;
                user.Fname = first_name;
                user.Lname = last_name;
                user.MailId = mail_id;
                user.MobileNumber = mobile_number;
                context.UserTables.Add(user);
                context.SaveChanges();

                return "Congratulations, a New User has been Created Successfully.\n\n" + 
                    "User ID : " + user.UserId + "\n" +
                    "First Name : " + user.Fname + "\n" +
                    "Last Name : " + user.Lname + "\n" +
                    "Mail ID : " + user.MailId + "\n" +
                    "Mobile Number : " + user.MobileNumber;
            }
        }

        [HttpPut("Modify a User")]
        public string ModifyUser(int user_id, string first_name, string last_name, string mail_id, string mobile_number)
        {
            using (var context = new OCMSystemDBContext())
            {
                UserTable user = context.UserTables.Where(user => user.UserId == user_id).FirstOrDefault();
                if(user != null)
                {
                    user.UserId = user_id;
                    user.Fname = first_name;
                    user.Lname = last_name;
                    user.MailId = mail_id;
                    user.MobileNumber = mobile_number;
                    context.SaveChanges();

                    return "Congratulations, Information about specified User has been Modified Successfully.\n\n" +
                        "User ID : " + user.UserId + "\n" +
                        "First Name : " + user.Fname + "\n" +
                        "Last Name : " + user.Lname + "\n" +
                        "Mail ID : " + user.MailId + "\n" +
                        "Mobile Number : " + user.MobileNumber;
                }

                return "User NOT Found !!!\n(Please, Enter a Valid User ID and Try Again.)";
            }
        }

        [HttpDelete("Delete a User")]
        public string DeleteUser(int user_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                UserTable user = context.UserTables.Where(user => user.UserId == user_id).FirstOrDefault();
                if (user != null)
                {
                    string user_name = user.Fname + " " + user.Lname;

                    context.UserTables.Remove(user);
                    context.SaveChanges();
                    return "Congatulations, User '" + user_name + "' has been Deleted Successfully.";
                }
                return "User NOT Found !!!\n(Please, Enter a Valid User ID and Try Again.)";
            }
        }

        [HttpPost("Create a New Delivery Executive")]
        public string CreateDeliveryExecutive(int de_id, string first_name, string last_name, string mail_id, string mobile_number, int salary)
        {
            using (var context = new OCMSystemDBContext())
            {
                Detable de = new Detable();

                de.Deid = de_id;
                de.Fname = first_name;
                de.Lname = last_name;
                de.MailId = mail_id;
                de.MobileNumber = mobile_number;
                de.Salary = salary;
                context.Detables.Add(de);
                context.SaveChanges();

                return "Congratulations, a New Delivery Executive has been Created Successfully.\n\n" +
                    "Delivery Executable ID : " + de.Deid + "\n" +
                    "First Name : " + de.Fname + "\n" +
                    "Last Name : " + de.Lname + "\n" +
                    "Mail ID : " + de.MailId + "\n" +
                    "Mobile Number : " + de.MobileNumber + "\n" +
                    "Salary : " + de.Salary;
            }
        }

        [HttpPut("Modify a Delivery Executive")]
        public string ModifyDeliveryExecutive(int de_id, string first_name, string last_name, string mail_id, string mobile_number, int salary)
        {
            using (var context = new OCMSystemDBContext())
            {
                Detable de = context.Detables.Where(de => de.Deid == de_id).FirstOrDefault();
                if (de != null)
                {
                    de.Deid = de_id;
                    de.Fname = first_name;
                    de.Lname = last_name;
                    de.MailId = mail_id;
                    de.MobileNumber = mobile_number;
                    de.Salary = salary;
                    context.SaveChanges();

                    return "Congratulations, Information about specified Delivery Executive has been Modified Successfully.\n\n" +
                        "Delivery Executive ID : " + de.Deid + "\n" +
                        "First Name : " + de.Fname + "\n" +
                        "Last Name : " + de.Lname + "\n" +
                        "Mail ID : " + de.MailId + "\n" +
                        "Mobile Number : " + de.MobileNumber + "\n" +
                        "Salary : " + de.Salary;
                }

                return "Delivery Executive NOT Found !!!\n(Please, Enter a Valid Delivery Executive ID and Try Again.)";
            }
        }

        [HttpDelete("Delete a Delivery Executive")]
        public string DeleteDeliveryExecutve(int de_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                Detable de = context.Detables.Where(de => de.Deid == de_id).FirstOrDefault();
                if (de != null)
                {
                    string user_name = de.Fname + " " + de.Lname;

                    context.Detables.Remove(de);
                    context.SaveChanges();
                    return "Congatulations, Delivery Executive '" + user_name + "' has been Deleted Successfully.";
                }
                return "Delivery Executive NOT Found !!!\n(Please, Enter a Valid Delivery Executive ID and Try Again.)";
            }
        }

        [HttpGet("Search a Consignment using Consignment ID")]
        public string SearchConsignment(int courier_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                CourierTable courier = context.CourierTables.Where(courier => courier.CourierId == courier_id).FirstOrDefault();
                if (courier != null)
                {
                    return "Consignment with specified Consginment ID found.\n\n" +
                        "Courier ID : " + courier.CourierId + "\n" +
                        "Consigner : " + courier.Consigner + "\n" +
                        "Consignee : " + courier.Consignee + "\n" +
                        "Consignment : " + courier.Consignment + "\n" +
                        "Package Type : " + courier.PackageType + "\n" +
                        "Package Weight : " + courier.PackageWeight + "\n" +
                        "Service Cost : " + courier.ServiceCost + "\n" +
                        "Delivery Status : " + courier.DeliveryStatus + "\n" +
                        "User ID : " + courier.UserId + "\n" +
                        "Delivery Executive ID : " + courier.Deid;
                }
                return "Consignment NOT Found !!!\n(Please, Enter a Valid Consignment ID and Try Again.)";
            }
        }

        [HttpPut("Assign Consignment to a Delivery Executive")]
        public string AssignConsignment(int courier_id, int de_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                CourierTable courier = context.CourierTables.Where(courier => courier.CourierId == courier_id).FirstOrDefault();
                if (courier != null)
                {
                    courier.Deid = de_id;
                    context.SaveChanges();
                    return "Congratulations, Consignment to the specified Delivery Executive has been assigned Successfully.\n\n" +
                        "Courier ID : " + courier.CourierId + "\n" +
                        "Consigner : " + courier.Consigner + "\n" +
                        "Consignee : " + courier.Consignee + "\n" +
                        "Consignment : " + courier.Consignment + "\n" +
                        "Package Type : " + courier.PackageType + "\n" +
                        "Package Weight : " + courier.PackageWeight + "\n" +
                        "Service Cost : " + courier.ServiceCost + "\n" +
                        "Delivery Status : " + courier.DeliveryStatus + "\n" +
                        "User ID : " + courier.UserId + "\n" +
                        "Delivery Executive ID : " + courier.Deid;
                }
                return "Consignment NOT Found !!!\n(Please, Enter a Valid Consignment ID and Try Again.)";
            }
        }

        [HttpGet("View All Users")]
        public IEnumerable<UserTable> GetAllUsers()
        {
            using (var context = new OCMSystemDBContext())
            {
                return context.UserTables.ToList();
            }
        }

        [HttpGet("View All Delivery Executives")]
        public IEnumerable<Detable> GetAllDE()
        {
            using (var context = new OCMSystemDBContext())
            {
                return context.Detables.ToList();
            }
        }
    }
}
