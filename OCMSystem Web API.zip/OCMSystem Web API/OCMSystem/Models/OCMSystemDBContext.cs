﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace OCMSystem.Models
{
    public partial class OCMSystemDBContext : DbContext
    {
        public OCMSystemDBContext()
        {
        }

        public OCMSystemDBContext(DbContextOptions<OCMSystemDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AdminTable> AdminTables { get; set; }
        public virtual DbSet<CourierTable> CourierTables { get; set; }
        public virtual DbSet<Detable> Detables { get; set; }
        public virtual DbSet<UserTable> UserTables { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=(localdb)\\MSSQLLocalDB;Database=OCMSystemDB;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AdminTable>(entity =>
            {
                entity.HasKey(e => e.AdminId)
                    .HasName("PK__AdminTab__719FE4E85193E5DC");

                entity.ToTable("AdminTable");

                entity.Property(e => e.AdminId)
                    .ValueGeneratedNever()
                    .HasColumnName("AdminID");

                entity.Property(e => e.Fname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("FName");

                entity.Property(e => e.Lname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("LName");

                entity.Property(e => e.MailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MailID");

                entity.Property(e => e.MobileNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<CourierTable>(entity =>
            {
                entity.HasKey(e => e.CourierId)
                    .HasName("PK__CourierT__CDAE76F658A7A836");

                entity.ToTable("CourierTable");

                entity.Property(e => e.CourierId)
                    .ValueGeneratedNever()
                    .HasColumnName("CourierID");

                entity.Property(e => e.Consignee)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Consigner)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Consignment)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Deid).HasColumnName("DEID");

                entity.Property(e => e.DeliveryStatus)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PackageType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.De)
                    .WithMany(p => p.CourierTables)
                    .HasForeignKey(d => d.Deid)
                    .HasConstraintName("FK__CourierTab__DEID__38996AB5");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.CourierTables)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("FK__CourierTa__UserI__37A5467C");
            });

            modelBuilder.Entity<Detable>(entity =>
            {
                entity.HasKey(e => e.Deid)
                    .HasName("PK__DETable__265CA96357A4540F");

                entity.ToTable("DETable");

                entity.Property(e => e.Deid)
                    .ValueGeneratedNever()
                    .HasColumnName("DEID");

                entity.Property(e => e.Fname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("FName");

                entity.Property(e => e.Lname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("LName");

                entity.Property(e => e.MailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MailID");

                entity.Property(e => e.MobileNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserTable>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__UserTabl__1788CCAC35BBDE63");

                entity.ToTable("UserTable");

                entity.Property(e => e.UserId)
                    .ValueGeneratedNever()
                    .HasColumnName("UserID");

                entity.Property(e => e.Fname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("FName");

                entity.Property(e => e.Lname)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("LName");

                entity.Property(e => e.MailId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MailID");

                entity.Property(e => e.MobileNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
