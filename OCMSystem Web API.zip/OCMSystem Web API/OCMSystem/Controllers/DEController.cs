﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OCMSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OCMSystem.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DEController : ControllerBase
    {
        [HttpGet("View Assigned Consignments")]
        public IEnumerable<CourierTable> SearchConsignment(int de_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                /*CourierTable courier = context.CourierTables.Where(courier => courier.Deid == de_id).FirstOrDefault();
                if (courier != null)
                {
                    return "Consignment with specified ID found.\n\n" +
                        "Courier ID : " + courier.CourierId + "\n" +
                        "Consigner : " + courier.Consigner + "\n" +
                        "Consignee : " + courier.Consignee + "\n" +
                        "Consignment : " + courier.Consignment + "\n" +
                        "Package Type : " + courier.PackageType + "\n" +
                        "Package Weight : " + courier.PackageWeight + "\n" +
                        "Service Cost : " + courier.ServiceCost + "\n" +
                        "Delivery Status : " + courier.DeliveryStatus + "\n" +
                        "User ID : " + courier.UserId + "\n" +
                        "Delivery Executive ID : " + courier.Deid; 
                }
                return "Consignment NOT Found !!!\n(Either no Consignments are assigned OR Please, Enter a Valid Delivery Executive ID and Try Again.)"; */

                return context.CourierTables.Where(courier => courier.Deid == de_id).ToList();
            }
        }

        [HttpPost("Change Consignment Status")]
        public string AssignConsignment(int courier_id, string status)
        {
            using (var context = new OCMSystemDBContext())
            {
                CourierTable courier = context.CourierTables.Where(courier => courier.CourierId == courier_id).FirstOrDefault();
                if (courier != null)
                {
                    courier.DeliveryStatus = status;
                    context.SaveChanges();
                    return "Congratulations, Delivery Status about specified Consignment has been Modified\n\n" +
                        "Courier ID : " + courier.CourierId + "\n" +
                        "Consigner : " + courier.Consigner + "\n" +
                        "Consignee : " + courier.Consignee + "\n" +
                        "Consignment : " + courier.Consignment + "\n" +
                        "Package Type : " + courier.PackageType + "\n" +
                        "Package Weight : " + courier.PackageWeight + "\n" +
                        "Service Cost : " + courier.ServiceCost + "\n" +
                        "Delivery Status : " + courier.DeliveryStatus + "\n" +
                        "User ID : " + courier.UserId + "\n" +
                        "Delivery Executive ID : " + courier.Deid;
                }
                return "Consignment NOT Found !!!\n(Please, Enter a Valid Consignment ID and Try Again.)";
            }
        }
    }
}
