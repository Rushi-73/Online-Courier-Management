﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OCMSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OCMSystem.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        [HttpPost("Book a New Consignment")]
        public string BookConsignment(int courier_id, string consigner, string consignee, string consignment, string package_type, float package_weight, float service_cost, string delivery_status, int user_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                UserTable user = context.UserTables.Where(user => user.UserId == user_id).FirstOrDefault();
                if (user != null)
                {
                    CourierTable courier = new CourierTable();
                    courier.CourierId = courier_id;
                    courier.Consigner = consigner;
                    courier.Consignee = consignee;
                    courier.Consignment = consignment;
                    courier.PackageType = package_type;
                    courier.PackageWeight = package_weight;
                    courier.ServiceCost = service_cost;
                    courier.DeliveryStatus = delivery_status;
                    courier.UserId = user_id;
                    context.CourierTables.Add(courier);
                    context.SaveChanges();

                    return "A new Consignment created Successfully.\n\n" +
                        "Courier ID : " + courier.CourierId + "\n" +
                        "Consigner : " + courier.Consigner + "\n" +
                        "Consignee : " + courier.Consignee + "\n" +
                        "Consignment : " + courier.Consignment + "\n" +
                        "Package Type : " + courier.PackageType + "\n" +
                        "Package Weight : " + courier.PackageWeight + "\n" +
                        "Service Cost : " + courier.ServiceCost + "\n" +
                        "Delivery Status : " + courier.DeliveryStatus + "\n" +
                        "User ID : " + courier.UserId;
                }

                return "User NOT Found !!!\n(Please, Enter a Valid User ID and Try Again.)";
            }
        }

        [HttpGet("Search a Consignment using Consignment ID")]
        public string SearchConsignment(int courier_id)
        {
            using (var context = new OCMSystemDBContext())
            {
                CourierTable courier = context.CourierTables.Where(courier => courier.CourierId == courier_id).FirstOrDefault();
                if (courier != null)
                {
                    return "Consignment with specified Consginment ID found.\n\n" +
                        "Courier ID : " + courier.CourierId + "\n" +
                        "Consigner : " + courier.Consigner + "\n" +
                        "Consignee : " + courier.Consignee + "\n" +
                        "Consignment : " + courier.Consignment + "\n" +
                        "Package Type : " + courier.PackageType + "\n" +
                        "Package Weight : " + courier.PackageWeight + "\n" +
                        "Service Cost : " + courier.ServiceCost + "\n" +
                        "Delivery Status : " + courier.DeliveryStatus + "\n" +
                        "User ID : " + courier.UserId + "\n" +
                        "Delivery Executive ID : " + courier.Deid;
                }
                return "Consignment NOT Found !!!\n(Please, Enter a Valid Consignment ID and Try Again.)";
            }
        }
    }
}
